<?php

namespace App;


class Notice extends Model
{

}

<?php

namespace App;

use \App\Model;

class Zan extends Model
{
    protected $table = "zans";


}
